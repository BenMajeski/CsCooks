﻿using CsKitchen.Models;
using Microsoft.AspNetCore.Mvc;


namespace CsKitchen.Controllers
{
    public class HomeController : Controller
    {
        private RecipeContext context { get; set; }
        public HomeController(RecipeContext ctx) => context = ctx;
        

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SubmitRecipe(Recipe newRecipe)
        {
            if (ModelState.IsValid)
            {
                context.allRecipes.Add(newRecipe);
                context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View("Index", newRecipe);
        }

        [HttpGet]
        public IActionResult SeeRecipe()
        {
            List<Recipe> allRecipes = context.allRecipes.ToList();
            return View("SeeRecipe", allRecipes);
        }
        [HttpGet]
        public IActionResult RecipeDetails(int id)
        {
            var recipe = context.allRecipes.Find(id);

            if (recipe == null)
            {
                return NotFound(); // or handle appropriately
            }

            return View(recipe);
        }

        [HttpGet] // This is the action for displaying the login page
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost] // This is the action for processing the login form
        public IActionResult Login(LogIn loginModel)
        {
            
            return RedirectToAction("Index");
        }
    }
}