﻿using Microsoft.EntityFrameworkCore;
namespace CsKitchen.Models
{
    public class KitchenContext : DbContext
    {
        //todo
    }
}
