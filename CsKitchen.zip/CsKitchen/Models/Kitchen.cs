namespace CsKitchen.Models
{
    public class Kitchen
    {
        //todo
    }
}